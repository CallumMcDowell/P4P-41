.. _custom-isa-extensions:

CORE-V Instruction Set Extensions
=================================

|corev| does not support any custom ISA Extensions internal to the core. Custom instructions can be added external to the core via the eXtension interface described in :ref:`x_ext`.
