Changelog
=========

.. changelog::
    :changelog-url: https://cv32e40x-user-manual.readthedocs.io/en/stable/#changelog
    :github: https://github.com/openhwgroup/cv32e40x/releases/

